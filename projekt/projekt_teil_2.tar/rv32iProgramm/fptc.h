// toDo: Inhalt von: https://github.com/mgetka/fptc-lib/blob/master/src/fptc.h hier einfügen und Anpassung vornehmen. 

