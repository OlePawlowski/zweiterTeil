#include <stdint.h>
#include <string.h>
#include "printf.h"
#include "fptc.h"
#include "dma_test.h"

#define APP_START (0x00000000)
#define APP_LEN   (0x200)
#define APP_ENTRY (0x00000000)


//toDo fpt fpt_atan2(fpt y, fpt x)


void main(void) {
   printf("\r\nRISC-V Prozessor der\n\rHumboldt Universitaet zu Berlin\r\n");

//toDo


   while(1);
}
