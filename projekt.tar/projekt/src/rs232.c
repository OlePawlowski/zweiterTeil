//
// Created by thorben on 4/29/25.
//
#include "rs232.h"
#include <stdio.h>


void printOut(uint8_t val) {
//toDo
}