//
// Created by thorben on 4/29/25.
//


#include <stdint.h>

void printOut(uint8_t val);
